 var moves = [];

        var cell;
        var symbol = "X";

        function markbox(cell) {
            if (cell.value == " ") {
                cell.value = symbol;
            }
            moves.push(cell.id);
            $.ajax({
                type: 'POST',
                url: 'http://localhost:5000/moves',
                headers: {'Content-Type': 'application/json'},
                data: JSON.stringify({moves: moves}),
                dataType: 'json',

            })
            .done(function(res) {
                var pole = res.moves
                moves = pole
                console.log(moves)
                console.log("POLE" + pole)
                var id = pole[pole.length - 1]
                console.log(id)
                $("#" + id).val('O')
            })
            .fail(function(err) {
                console.log(err)
            })

        }

        function run(){
         table(10)
         console.log(moves);
         for (var i = 0; i < 10; i++){
              console.log('player x in on the move')
            }
        }

        function table(n){
            var pos = 0;
            document.write("<table class=tabulka>");
                for (var a=0; a < n; a++) {
                    document.write("<tr>");
                    for(var b=0; b<n; b++) {
                        pos = a*n+b;
                        document.write("<td>" + "<input id=" + pos + ' type=button value=" " onclick= markbox(this) class=button>' + "</td>");
                    }
                    document.write("</tr>");
                }
            document.write("<table>");
        }

run()